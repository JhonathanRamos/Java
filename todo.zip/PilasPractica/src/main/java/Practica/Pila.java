package Practica;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.Stack;

public class Pila {

    static Stack pila = new Stack();
    static LinkedList<String> ordenar = new LinkedList<>();
    static String aux;

    public static void main(String[] args) {

        pila.push(new Disco("Instrumentales", "Instrumentales"));
        pila.push(new Disco("Clasicos", "Clasicos"));
        pila.push(new Disco("Clasicos", "Clasicos"));
        pila.push(new Disco("Boleros", "Boleros"));
        pila.push(new Disco("Instrumentales", "Instrumentales"));
        pila.push(new Disco("Bailables", "Bailables"));
        pila.push(new Disco("Artistico", "Artistico"));
        pila.push(new Disco("Boleros", "Boleros"));
    }
    
       public static void insertarArreglo() {
       
        while(!pila.isEmpty()){
            Disco p = (Disco)pila.pop();
            String alv = p.toString();
            
            ordenar.add(alv);
        }
       }
       
           public static void ordenarPeriodicos(){
        for(int i=0;(i<ordenar.size()-1);i++){
            for(int j=0;(j<ordenar.size()-1);j++){
                if(ordenar.get(j).after(ordenar.get(j+1))){
                    aux=ordenar.get(j);
                    ordenar.set(j,ordenar.get(j+1));
                    ordenar.set(j+1,aux);   
                }
            }
        }
    }
    }

