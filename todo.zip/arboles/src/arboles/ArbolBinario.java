package arboles;

public class ArbolBinario {
    
    NodoArbol raiz;
    
    public ArbolBinario(){
        raiz = null;
    }
    
    //metodo para agregar un nodo
    public void agregarNodo(int d){
        NodoArbol nuevo = new NodoArbol(d);
        if(raiz==null){
            raiz = nuevo;
        }
        else{
            NodoArbol auxiliar = raiz;
            NodoArbol padre;
            
            while(true){
                padre = auxiliar; //valor de la raiz
                if(d<auxiliar.dato){
                    auxiliar = auxiliar.hijoIzq;
                    if(auxiliar==null){
                        padre.hijoIzq = nuevo;
                        return;//finalizar
                    }
                }else{
                    auxiliar = auxiliar.hijoDer;
                    if(auxiliar==null){
                        padre.hijoDer = nuevo;
                        return;
                    }
                }
            }
        }
    }
    
    /* si el arbol esta vacio*/
    public boolean estaVacio()
    {
        return raiz == null;
    }
    //recorrido InOrden
    public void inOrden(NodoArbol r)
    {
        if(r!=null)
        {
            inOrden(r.hijoIzq);
            System.out.println("["+r.dato+"]");
            inOrden(r.hijoDer);
        }
    }
    
    //RECORRIDO PREORDEN
    
     public void preOrden(NodoArbol r)
    {
        if(r!=null)
        {
            System.out.println("["+r.dato+"]");
            preOrden(r.hijoIzq);
            preOrden(r.hijoDer);
        }
    }
     
        public void postOrden(NodoArbol r)
    {
        if(r!=null)
        {
           
            postOrden(r.hijoIzq);
            postOrden(r.hijoDer);
             System.out.println("["+r.dato+"]");
        }
    }
    
}
