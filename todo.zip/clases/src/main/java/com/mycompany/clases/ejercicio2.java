package com.mycompany.clases;

public class ejercicio2 {
     
    public static void main(String[] args) {
        int ini = 1;
        int fin = 30;
        int mult = 7;
        int valor = 0;
        
        multiplos(ini, fin, mult, valor);
        
    }

public static void multiplos(int inicio , int fin , int multiplo , int valor)
{
if(inicio==fin)
{
    System.out.println(valor);
}else if(inicio%multiplo==0)
{
    System.out.println(inicio);
    multiplos(inicio+1,fin,multiplo,valor);
}else
{
    multiplos(inicio+1,fin,multiplo,valor);
}

}
}