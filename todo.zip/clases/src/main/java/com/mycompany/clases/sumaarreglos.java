/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clases;

/**
 *
 * @author ramos
 */
public class sumaarreglos {
     public static void main(String[] args) {
        int[]num = {2,5,6,2,3,4};
        System.out.println("suma: "+sumArreglo(num,0));
    }
    
    public static int sumArreglo(int[]arre,int cont){
        int suma=0;
        if(cont == arre.length){
            return suma;
        }else{
            suma+=arre[cont];
            return suma+sumArreglo(arre, cont+1);
            
        }
        
    }
}
