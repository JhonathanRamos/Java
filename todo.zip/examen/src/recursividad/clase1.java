package recursividad;

public class clase1 {
    public static void main(String[] args) {
        recursivo r = new recursivo();
        r.Imprimir(1);
    }
}
