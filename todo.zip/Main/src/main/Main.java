package main;

public class Main extends tipos{
    
     int autosPequeños = 0;
     int autosMedianos = 0;
     int autosGrandes = 0;

    public  void main(String[] args) {
        String[] autos = {"pequeño", "pequeño", "mediano", "mediano", "grande","mediano", "mediano", "mediano", "grande","mediano","pequeño", "grande","grande"};
        seleccionarArray(autos, 0);
        System.out.println("Cantidad de Autos Pequeños: " + autosPequeños);
        System.out.println("Cantidad de Autos Medianos: " + autosMedianos);
        System.out.println("Cantidad de Autos Grandes: " + autosGrandes);
    }

    public  void seleccionarArray(String[] autos, int indice) {
        if (indice != autos.length) {
            if (autos[indice].equals("pequeño")) {
                autosPequeños++;
            }
            if (autos[indice].equals("mediano")) {
                autosMedianos++;
            }
            if (autos[indice].equals("grande")) {
                autosGrandes++;
            }
            seleccionarArray(autos, indice + 1);
        }
    }
}
