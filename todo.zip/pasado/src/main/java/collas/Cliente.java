package collas;

public class Cliente {

    private String ticket;
    private String nombre;
    private int tipoAtencion;

    public Cliente(String ticket, String nombre, int tipoAtencion) {
        this.ticket = ticket;
        this.nombre = nombre;
        this.tipoAtencion = tipoAtencion;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTipoAtencion() {
        return tipoAtencion;
    }

    public void setTipoAtencion(int tipoAtencion) {
        this.tipoAtencion = tipoAtencion;
    }
    
    @Override
    public String toString(){
        return "Cliente con tiket" + ticket + " tipo atencion " + tipoAtencion + "Nombre" + nombre;
    }
}
