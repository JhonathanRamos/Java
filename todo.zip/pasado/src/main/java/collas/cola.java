package collas;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;

public class cola {

    public static void main(String[] args) {

        /*
            Queue<String> alumnos = new LinkedList<String>();
            
            alumnos.add("Lucia Perez");
            alumnos.add("Rocio zer");
            alumnos.add("Andre lade");
            alumnos.add("jose antoni");
            alumnos.add("Lucho zou");
            
            //El alumno a ser atendido
            System.out.println("El alumno a ser atendido es: "+ alumnos.peek());
            
            //Desencolar
            alumnos.remove();
            //Atencion alumno
                System.out.println("El alumno a ser atendido es: "+ alumnos.peek());
                
                //la cola vacia
                System.out.println ( " La cola esta vacia ? " + alumnos.isEmpty ());
                
                //recorrido
                while(!alumnos.isEmpty()){
                    System.out.println("Atendiendo alumnos: " + alumnos.remove());
                }
                   
         */
        Queue<Cliente> clientes = new LinkedList<Cliente>();
         Collections.sort(clientes);

        clientes.add(new Cliente("A", "ROSA", 1));
        clientes.add(new Cliente("B", "ROSA", 2));
        clientes.add(new Cliente("C", "ROSA", 3));
        clientes.add(new Cliente("D", "ROSA", 2));
        clientes.add(new Cliente("E", "ROSA", 3));

        //RECORRIDO
                      /*  while(!clientes.isEmpty()){
                            Cliente cli = (Cliente)clientes.remove();
                    System.out.println("Atendiendo tikets: " + cli.getTicket()+ "Tipo atencion: " + cli.getTipoAtencion()); }
*/
                      /*
                      while(!clientes.isEmpty()){                  
                          System.out.println(clientes.remove());}
*/
                 Collections.sort(clientes);
    }
}
