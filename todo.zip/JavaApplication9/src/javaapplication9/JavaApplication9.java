
package javaapplication9;

import java.util.Scanner;

public class JavaApplication9 {

    public static void main(String[] args) {
       
  
          Scanner scanner = new Scanner(System.in);
        String nombreUsuario, contraseña;
        
        System.out.println("Ingrese su nombre de usuario: ");
        nombreUsuario = scanner.nextLine();
        
        System.out.println("Ingrese su contraseña: ");
        contraseña = scanner.nextLine();
        
        if (nombreUsuario.equals("david") && contraseña.equals("yato")) {
            System.out.println("Inicio de sesión exitoso!");
        } else {
            System.out.println("Nombre de usuario o contraseña incorrectos. Inténtelo de nuevo.");
        }
 }
}

        

