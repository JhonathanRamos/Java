
package honkai;

public class hanoi {
    public static void main(String[] args) {
		hanoi hanoi = new hanoi();
		hanoi.hanoi(3,1,2,3);
	}
	
	public static void hanoi(int n , int t1 , int t2 , int t3)
	{
		//caso base
		if(n==1)
		{
			System.out.println("Mover disco de torre: " + t1+"a torre "+t3);
		}
	else
	{
		hanoi (n-1, t1,t3,t2);
		System.out.println("mover disco de torre: "+t1+"a la torre: "+t3);
		hanoi(n-1,t2,t1,t3);
	}
	
	}

}
