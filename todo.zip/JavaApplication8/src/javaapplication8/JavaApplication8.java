package javaapplication8;

import java.util.Scanner;

public class JavaApplication8 {

    public static void main(String[] args) {
//FACTORTIAL
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número:");
        int n = scanner.nextInt();

        int factorial = 1;
        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
        System.out.println("La factorial de " + n + " es:"+factorial);
    }
}

