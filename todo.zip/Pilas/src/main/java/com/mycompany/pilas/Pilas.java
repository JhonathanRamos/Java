package com.mycompany.pilas;

import java.util.Scanner;

public class Pilas {

    public static void main(String[] args) {
       //calculadora
System.out.println("hello");
    }
}
