package com.mycompany.dios;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Periodico {

    int anio;

    public Periodico(int anio) {
        this.anio = anio;

    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public Date volverFecha(String fecha) throws ParseException {
        SimpleDateFormat formato = new SimpleDateFormat("yyyy");
        Date fecha1 = formato.parse(fecha);
        return fecha1;
    }


}
