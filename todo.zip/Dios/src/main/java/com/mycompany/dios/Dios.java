package com.mycompany.dios;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Stack;

public class Dios {
        
      static Stack pilaPeriodico = new Stack();
      static LinkedList <Date>ordenar = new LinkedList<>();
      static Date aux;
      public static void main(String[] args) throws ParseException {
        
        
        pilaPeriodico.push(new Periodico(2001));
        pilaPeriodico.push(new Periodico(2015));
        pilaPeriodico.push(new Periodico(2000));
        pilaPeriodico.push(new Periodico(2020));
        pilaPeriodico.push(new Periodico(2022));
        pilaPeriodico.push(new Periodico(2022));
        pilaPeriodico.push(new Periodico(2002));
        pilaPeriodico.push(new Periodico(2003));

        
        /*System.out.println("tam pilaPeriodico: "
                +pilaPeriodico.size());*/
        insertarArreglo();//inserta en un arreglo auxiliar
        
        ordenarPeriodicos();
        /*System.out.println("tam ordenado: "
                +ordenar.size());*/
        for(int i=ordenar.size()-1;i>=0;i--){
            SimpleDateFormat formato = new SimpleDateFormat("yyyy");  
            String stringDate= formato.format(ordenar.get(i));  
            System.out.println(stringDate);
        }
        
    }
    //insercion en el linkedlist
    public static void insertarArreglo() throws ParseException{
       
        while(!pilaPeriodico.isEmpty()){
            Periodico p = (Periodico)pilaPeriodico.pop();
            String anio1 = p.getAnio()+"";
            String fechaCompleta = anio1;
            Date miFecha = p.volverFecha(fechaCompleta);
            
            ordenar.add(miFecha);
        }
    }
    
    public static void ordenarPeriodicos(){
        for(int i=0;(i<ordenar.size()-1);i++){
            for(int j=0;(j<ordenar.size()-1);j++){
                if(ordenar.get(j).after(ordenar.get(j+1))){
                    aux=ordenar.get(j);
                    ordenar.set(j,ordenar.get(j+1));
                    ordenar.set(j+1,aux);   
                }
            }
        }
    }
}

