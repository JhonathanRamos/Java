package examenn;

import java.util.LinkedList;

public class hola {

   
    public static void main(String[] args) {
         LinkedList<String> lista=new LinkedList<>();
         lista.add("pequeño");
         lista.add("pequeño");
         lista.add("pequeño");
         lista.add("pequeño");
         lista.add("mediano");
         lista.add("mediano");
         lista.add("grande");
         System.out.println(lista);
         int p=0,m=0,g=0,i=0; 
         int tam=lista.size();
         contar( lista,p,  m, g , i , tam);
         
    } 
    static void contar(LinkedList<String> lista,int p, int m, int g , int con ,int tam){
        if(con<tam){
               if (lista.get(con).equals("pequeño")) {
                p++;
                con++;
                contar(lista,p, m, g , con ,tam);
               }
                else{
               if (lista.get(con).equals("mediano")) {
                   m++;
                   con++;
                   contar(lista,p, m, g , con ,tam);
                }
            else{
                 g++;
                 con++;
                 contar(lista,p, m, g , con ,tam);                 
                }
             }
           /*System.out.println(mult+"*"+inicio+"="+inicio*mult);
           multiplicacion(mult,inicio+1);*/
         }
        else{
            System.out.println("existen "+p+" autos pequeños");
            System.out.println("existen "+m+" autos medianos");
            System.out.println("existen "+g+" autos grandes");
      }
    }
}

    


