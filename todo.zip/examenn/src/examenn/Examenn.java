package examenn;

public class Examenn 
{
    static int autosPequeños = 0;
    static int autosMedianos = 0;
    static int autosGrandes = 0;
    
    public static void main(String[] args) {
      String[] autos = {"pequeño", "pequeño", "mediano", "mediano", "grande","mediano", "mediano", "mediano", "grande","mediano","pequeño", "grande","grande"};
      seleccionarArray(autos,0);
      System.out.println("Cantidad de Autos Pequenos: " + autosPequeños);
      System.out.println("Cantidad de Autos Medianos: " + autosMedianos);
      System.out.println("Cantidad de Autos Grandes: " + autosGrandes);
    }
     public static void seleccionarArray(String[] autos, int indice) {
           if (indice != autos.length) {
          if (autos[indice].equals("pequeño")) {
                 autosPequeños++;
                 
          }
              if (autos[indice].equals("mediano")) {
               autosMedianos++;
               }
              if (autos[indice].equals("grande")) {
               autosGrandes++;
                }
                 seleccionarArray(autos, indice + 1);
                 }
     }
}
