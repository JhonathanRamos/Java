
package clases1;

public class Clases1 {
    public static void main(String[] args) {
       
        //saber si los arrelgos son iguales toamndo el cuenta el tamañp y los valores almacenados
        int []a = {1,3,5,7,9,11};
        int []b = {1,3,5,7,9,11};
        
        if(a.length==b.length){
            System.out.println(arreglosIguales(a, b, 0));
        }else{
            System.out.println(false);  
    }
    }
    
    public  static boolean arreglosIguales(int[]a,int[]b,int indice){
        if(indice==a.length){
            return true;
        }else if(a[indice]!=b[indice]){
            return false;
        }else{
            return arreglosIguales(a, b, indice+1);
        }
    }
}