package arbolbinario;

public class ArbolBinario {

      NodoArbol raiz;
    
    public ArbolBinario()
    {
        raiz = null;
    }
    
    //metodo para agregar un nodo
    public void agregarNodo(int d)
    {
        NodoArboluno nuevo = new NodoArboluno(d);
        
        if(raiz==null)
        {
            raiz = nuevo;
        }
        else
        {
            NodoArbol auxiliar = raiz;
            
            NodoArbol padre;
            
            while(true)
            {
                padre = auxiliar
            }
        }
    }
    
}
