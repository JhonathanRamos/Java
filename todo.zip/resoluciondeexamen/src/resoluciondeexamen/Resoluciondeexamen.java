
package resoluciondeexamen;

public class Resoluciondeexamen {

  
    public static void main(String[] args) {
       
    }
    
}
