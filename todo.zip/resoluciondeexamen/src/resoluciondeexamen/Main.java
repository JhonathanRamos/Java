
package resoluciondeexamen;

public class Main {
    static int autosPequeños = 0;
    static int autosMedianos = 0;
    static int autosGrandes = 0;
    
    private static void method() {
        
    }
    

}
