
package com.mycompany.arbol;

class NodoArbol {
    
}
