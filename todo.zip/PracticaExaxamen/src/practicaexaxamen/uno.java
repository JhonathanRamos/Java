package practicaexaxamen;

public class uno {
    public static void main(String[] args) {
       

        int b = 2 ;
        for (int a = 10; a < 21; a++) {
            System.out.println(a +"*"+ b + "=" +(a*b));
        }
    }
}
