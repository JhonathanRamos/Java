package resolucion;

public class clase {
    
    public static void main(String[] args) {
        
        String Autos[]={"pequeño","pequeño","mediano","mediano","grande"};
        
        Autos
        
    }
}
