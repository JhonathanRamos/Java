
package resolucion;

public class Autos {
      public void Imprimir(String pequeño,String mediano , String grande)
    {
        if(pequeño==pequeño)
        {
            System.out.println("");  
        }
    }
}
